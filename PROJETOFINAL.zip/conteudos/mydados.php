<style>
    #mydados{
        text-transform: uppercase;
        margin-left: 55px;
        padding: 15px;
    }
    #mydados td{
        padding-left: 15px;
        width: 180px;
    }
</style>
<div id="mydados">
<?php
        require_once 'modelos/Pessoa.php';
        $pessoa = new Pessoa();
        $id = ($_SESSION["id"]);
        $r = ($pessoa->mydados($id));
        if($r){
            echo"<table><tr>"
              . "<td>".$r["nome"]."</td><tr>"
              . "<tr><td>".$r["endereco"]
              . $r["numero"]
              . $r["complemento"]."</td>"
              . "<tr><td>".$r["bairro"]."</td></tr>"
              . "<tr><td>".$r["cidade"]
              . "             -        "
              . $r["estado"]."</td></tr>"
              . "<tr><td>".$r["cpf"]."</td></tr>"
              . "<tr><td>".$r["telefone"]."</td></tr>"
              . "<tr><td>".$r["email"]."</td></tr>"
              . "</table>";
        }
        echo "<br><br><br>";
        $ida = ($_SESSION["id"]);
        $view = ($pessoa->myagenda($ida));
        foreach ($view as $v){
                echo "<table><tr><td>"
                   . $v["atividade"]
                   . "</td><td>"
                   . $v["dataHora"]
                   . "</td></tr>";            ;
        } 
        echo "</table>";
        ?>
        </div>