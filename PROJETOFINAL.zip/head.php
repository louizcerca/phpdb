    <head>
        <meta charset="UTF-8">
       
        <link rel="stylesheet" href="styles/cssFonts.css">
        <title>Sistema de Cadastro</title>
<script src="scripts/jqueryCalendar/jquery-1.6.2.min.js"></script>
<script src="scripts/jqueryCalendar/jquery-ui-1.8.15.custom.min.js"></script>
<link rel="stylesheet" href="scripts/jqueryCalendar/jqueryCalendar.css">

    </head>
