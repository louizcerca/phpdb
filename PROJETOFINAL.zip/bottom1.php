
    <div id="bot">
        <footer>

                <div id="marca">
                    <img src="images/logo.fw.png" class="logo">
                    <p>Rua Santa Luzia - 735 - Centro</p>
                </div>
            <div id="social">
                <p>Siga-nos também nas redes sociais</p>
                <img src="images/facebook.png" class="logo">
                <img src="images/googleplus.png" class="logo">
                <img src="images/twitter.png" class="logo">
                <img src="images/youtube.png" class="logo">
             </div>

        </footer>
    </div>