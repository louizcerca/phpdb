<link rel="stylesheet" href="styles/login.css">
<div id="login">
<form method='post' action="validaf.php" class="left">
               <h1>Login</h1>  <input class='input' type='text' name='login' size='20' maxlength='25'placeholder='Login'><br>
               <h1>Senha</h1> <input class='input' type='password' name='senha' size='20'placeholder='Senha'><br>
               <h2><input type='submit' value='Entrar'></h2>
    </form>
</div>