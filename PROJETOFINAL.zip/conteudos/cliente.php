
        <?php include "clientehead.php"?>
      

        <ul class="listcl">
        <li><a href="?p=avaliacao" alt="botao1"><img src="imagens/ph-clientarea.jpg"></a></li>
        <li><a href="?p=pilates" alt="botao1"><img src="imagens/ph-clientarea.jpg"></a></li>
        <li><a href="?p=fisio" alt="botao1"><img src="imagens/ph-clientarea.jpg"></a></li>
    </ul>
	           
</div>