<div id="top">
    <header>
        <nav>
            <ul>
                <li><a href="index.php">daFence</a></li>
                <li><a href="index.php">daFence</a></li>
                <li><a href="index.php">daFence</a></li>
                <li><a href="index.php">daFence</a></li>            
            </ul>
        </nav>
    </header>
</div>