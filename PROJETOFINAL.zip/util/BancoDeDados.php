<?php

class BancoDeDados{
    function conecta(){
        try{
            /*$local = "127.0.0.1";
            $banco = "projeto";
            $username = "root";
            $passwd="";*/
            $local = "mysql.hostinger.com.br";
            $banco = "u515401830_daf";
            $username = "u515401830_louiz";
            $passwd="doritos";
            $con = new PDO("mysql:host=".$local.";dbname=".$banco, $username, $passwd) or die("Erro ao Conectar!");
            return $con;
        } catch (PDOException $e){
            echo 'Erro: '.$e;
        }
    }
}
