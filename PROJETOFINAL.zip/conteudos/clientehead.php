<link rel="stylesheet" href="styles/cliente.css">

<div id="cliente">    
