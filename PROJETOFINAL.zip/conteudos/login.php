<link rel="stylesheet" href="styles/login.css">
<div id="login">
    <form method='post' action='valida.php'  class="left">
               <h1>Login</h1>  <input class='input' type='text' name='login' size='20' maxlength='25'placeholder='Login'><br>
               <h1>Senha</h1> <input class='input' type='password' name='senha' size='20'placeholder='Senha'><br>
               <h2><input type='submit' value='Entrar'></h2>
    </form>
    <div class="right">
        <h1>
            Vantagens de ser aluno da DaFence
        </h1>
        <ul class="list1">
            <li>Vantagem 1</li>
            <li>Vantagem 2</li>
            <li>Vantagem 3</li>
        </ul>
    </div>
</div>