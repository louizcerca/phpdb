<?php
class BancoDeDados{
    var $conexao;
    function BancodeDados(){
        $this->conexao = new PDO("mysql:host=127.0.0.1");
    }
}
?>