function fatorial(){
    var x = document.form.numero.value;
    var res = 1;
    while(x >= 1){
        res = res * x;
        x--;
    }
    document.getElementById("texto").innerHTML = "O fatorial é "+res;  
}


