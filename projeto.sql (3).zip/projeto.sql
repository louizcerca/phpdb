--
-- Database: `projeto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

CREATE TABLE `agenda` (
  `atividade` varchar(25) NOT NULL,
  `idagenda` int(11) NOT NULL,
  `idaluno` int(11) NOT NULL,
  `nomealuno` varchar(50) NOT NULL,
  `dataHora` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `agenda`
--

INSERT INTO `agenda` (`atividade`, `idagenda`, `idaluno`, `nomealuno`, `dataHora`) VALUES
('avaliacao', 1, 1, 'sharion', '2015-12-22 12:00:00'),
('fisioterapia', 2, 2, 'Luiz Henrique Cerca', '2015-12-31 16:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno`
--

CREATE TABLE `aluno` (
  `idaluno` int(11) NOT NULL,
  `nome` varchar(60) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `numero` varchar(20) DEFAULT NULL,
  `complemento` varchar(20) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `cpf` varchar(13) DEFAULT NULL,
  `rg` varchar(25) DEFAULT NULL,
  `telefone` varchar(25) DEFAULT NULL,
  `datanasc` datetime DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `aluno`
--

INSERT INTO `aluno` (`idaluno`, `nome`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cpf`, `rg`, `telefone`, `datanasc`, `sexo`, `email`, `senha`) VALUES
(1, 'sharion', 'sss', '111', '11', 'sasasd', 'uniao da vitoria', 'SC', '1337', '24', '22222', '1994-02-02 00:00:00', 'o', 'lale@cs.com', '$1$salt$kqNI5AJoJdN1WgWoNslBD0'),
(2, 'Luiz Henrique Cerca', '', '', '', '', '', '', '', '', '', '2005-01-01 00:00:00', 'o', 'luizhcerca@gmail.com', '$1$salt$kqNI5AJoJdN1WgWoNslBD0');

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor`
--

CREATE TABLE `professor` (
  `idPessoa` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `endereco` varchar(50) NOT NULL,
  `numero` int(11) NOT NULL,
  `complemento` varchar(25) NOT NULL,
  `bairro` varchar(25) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `rg` varchar(25) NOT NULL,
  `telefone` varchar(25) NOT NULL,
  `datanasc` date NOT NULL,
  `sexo` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `senha` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `professor`
--

INSERT INTO `professor` (`idPessoa`, `nome`, `endereco`, `numero`, `complemento`, `bairro`, `cidade`, `estado`, `cpf`, `rg`, `telefone`, `datanasc`, `sexo`, `email`, `senha`) VALUES
(1, 'sharion', '', 0, '', '', '', '', '', '', '', '2015-01-01', 'on', 'lale@cs.com', '1234'),
(2, 'Luiz Henrique Cerca', 'sa viana', 0, '11', 'graja', 'rj', 'rj', '1337', '2121', '121212', '2015-01-01', 'on', 'isabelcerca@uol.com.br', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`idagenda`);

--
-- Indexes for table `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`idaluno`);

--
-- Indexes for table `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`idPessoa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agenda`
--
ALTER TABLE `agenda`
  MODIFY `idagenda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `aluno`
--
ALTER TABLE `aluno`
  MODIFY `idaluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `professor`
--
ALTER TABLE `professor`
  MODIFY `idPessoa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
