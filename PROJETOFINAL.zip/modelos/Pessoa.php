<?php
class Pessoa {
    var $idPessoa;
    var $nome;
    var $cpf;
    var $rg;
    var $sexo;
    var $telefone;
    var $datanasc;
    var $endereco;
    var $numero;
    var $complemento;
    var $bairro;
    var $cidade;
    var $estado;
    var $email;
    var $senha;
  //agenda
    var $atividade;
    var $idagenda;
    var $idaluno;
    var $dataHora;
    
    function cadastro (){
        try{
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("insert into aluno value (null,:nome, :endereco, :numero, :comp, :bairro, :cidade, :estado, :cpf, :rg, :tel, :datanasc, :sexo, :email, :senha)");

            $stman->bindValue(':nome', $this->nome );
            $stman->bindValue(':endereco', $this->endereco );
            $stman->bindValue(':numero', $this->numero );
            $stman->bindValue(':comp', $this->complemento );
            $stman->bindValue(':bairro', $this->bairro );
            $stman->bindValue(':cidade', $this->cidade );
            $stman->bindValue(':estado', $this->estado );
            $stman->bindValue(':cpf', $this->cpf );
            $stman->bindValue(':rg', $this->rg );
            $stman->bindValue(':tel', $this->tel );
            $stman->bindValue(':datanasc', $this->datanasc );
            $stman->bindValue(':sexo', $this->sexo );
            $stman->bindValue(':email', $this->email);
            $stman->bindValue(':senha', $this->senha);
            

            $stman->execute();
            return true;
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
            return false;
        }
    }
    function cadastrof (){
        try{
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("insert into professor value (null,:nome, :endereco, :numero, :comp, :bairro, :cidade, :estado, :cpf, :rg, :tel, :datanasc, :sexo, :email, :senha)");

            $stman->bindValue(':nome', $this->nome );
            $stman->bindValue(':endereco', $this->endereco );
            $stman->bindValue(':numero', $this->numero );
            $stman->bindValue(':comp', $this->complemento );
            $stman->bindValue(':bairro', $this->bairro );
            $stman->bindValue(':cidade', $this->cidade );
            $stman->bindValue(':estado', $this->estado );
            $stman->bindValue(':cpf', $this->cpf );
            $stman->bindValue(':rg', $this->rg );
            $stman->bindValue(':tel', $this->tel );
            $stman->bindValue(':datanasc', $this->datanasc );
            $stman->bindValue(':sexo', $this->sexo );
            $stman->bindValue(':email', $this->email);
            $stman->bindValue(':senha', $this->senha);
            

            $stman->execute();
            return true;
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
            return false;
        }
    }
    function agendar (){
        try{
            
            //echo "xxx";
            
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            
            $stman = $conexao->conecta()->prepare("insert into agenda value (:atividade,null, :idaluno, :nomealuno, :datahora)");

            $stman->bindValue(':atividade', $this->atividade );
            $stman->bindValue(':idaluno', $this->idaluno );
            $stman->bindValue(':nomealuno', $this->nome );
            $stman->bindValue(':datahora', $this->dataHora );            

            $stman->execute();
            return true;
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
            return false;
        }
    }
    /*function algorit($login){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select datanasc from pessoa where email = :email");
            $stman->bindValue(':email', $login);
            $stman->execute();  
            return mysql_result($stman);
        } catch (PDOException $e){
            echo 'HUEHUEHUE: '.$e ;
        }
    }*/
    function signin($login, $senha){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select * from aluno where email = :email and senha = :senha");

            $stman->bindValue(':email', $login);
            $stman->bindValue(':senha', $senha);

            $stman->execute();  
            return $stman->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e){
            echo 'HUEHUEHUE: '.$e ;
        }
    }
    function signinf($login, $senha){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select * from func where email = :email and senha = :senha");

            $stman->bindValue(':email', $login);
            $stman->bindValue(':senha', $senha);

            $stman->execute();  
            return $stman->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e){
            echo 'HUEHUEHUE: '.$e ;
        }
    }
    function listar($busca){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select * from pessoa where nome like :busca");

            $stman->bindValue(':busca', $busca."%" );
            $stman->execute();  
            return $stman->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
        }
    }
    function mydados($id){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select * from aluno where idaluno like :id");

            $stman->bindValue(':id', $id );
            $stman->execute();  
            return $stman->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
        }
    }
    function myagenda($idaluno){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select * from agenda where idaluno like :id order by dataHora");

            $stman->bindValue(':id', $idaluno );
            $stman->execute();  
            return $stman->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
        }
    }
    function agendaall(){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("select * from agenda order by dataHora");

            $stman->execute();  
            return $stman->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e){
            echo 'Erro: '.$e ;
        }
    }

    function apagar($id){
        try {
            require_once 'util/BancodeDados.php';
            $conexao = new BancoDeDados();
            $stman = $conexao->conecta()->prepare("delete from pessoa where idpessoa = :id;");
 
            $stman->bindValue(':id', $this->$id );
            $stman->execute();  
            return true;
    } catch (PDOException $e){
        echo 'Erro: '.$e ;
    }
}
}
