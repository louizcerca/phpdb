
<div class="sistema">
      <a class="voltar" href="index.php?p=func&c=sist">Voltar</a><p>
<h1>
   Agenda de atividades
</h1>

<?php       
        require_once 'modelos/Pessoa.php';
        $pessoa = new Pessoa();        
        $all = ($pessoa->agendaall());
        foreach ($all as $a){
                echo "<table><tr><td>"
                   . $a["atividade"]
                   . "</td><td>"
                   . $a["nomealuno"]
                   . "</td><td>"
                   . $a["dataHora"]
                   . "</td></tr>";            ;
        } 
        echo "</table>";
        
        ?>

</div>