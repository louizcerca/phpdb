<form name="form" method="post" onSubmit="return validaForm(this)">
        <h2>(*)Dados Obrigatórios</h2>

        <select name="dia">
            <?php
            for ($x = 1; $x <= 31; $x++){
                echo "<option value= $x > $x</option>";
            }
                    ?>
        </select>
        <select name="mes">
            <?php
            for ($x = 1; $x <= 12; $x++){
                echo "<option value= $x > $x</option>";
            }
                    ?>
        </select>
        <select name="ano">
            <?php
            $ano = date(Y);
            for ($x= $ano; $x >= $ano-120; $x--){
                echo "<option value= $x > $x</option>";
            }
                    ?>
        </select><p>
        <input type="submit" value="Marcar" style="margin-left: 280px;"><p><p>
    </form> 

