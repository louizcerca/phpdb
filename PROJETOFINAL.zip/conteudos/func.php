
        <?php include "clientehead.php"?>
      

        <ul class="listcl">
        <li><a href="?p=cadastrof&c=sist" alt="botao1"><img src="imagens/ph-clientarea.jpg"></a></li>
        <li><a href="?p=cadastroadm&c=sist" alt="botao1"><img src="imagens/ph-clientarea.jpg"></a></li>
        <li><a href="?p=agenda&c=sist" alt="botao1"><img src="imagens/ph-clientarea.jpg"></a></li>
    </ul>
	           
</div>