        <?php include "clientehead.php"?>


<h1>AGENDAMENTO PILATES</h1>
<form class="forma" name="agendar" method="post" onSubmit="return validaForm(this)">
    <p>Data <input type="date" name="data"></p>
    <p>Horario <select name="horario">        
            <?php
            for ($x = 9; $x <= 19; $x++){
                echo "<option value= $x > $x:00</option>";
                echo "<option value= $x > $x:30</option>";
            }
                    ?>
</select></p>
        <script src="scripts/jqueryCalendar/jquery-1.6.2.min.js"></script>
        <script src="scripts/jqueryCalendar/jquery-ui-1.8.15.custom.min.js"></script>
        <link rel="stylesheet" href="scripts/jqueryCalendar/jqueryCalendar.css">
            <script>
                        jQuery(function() {
                                        jQuery( "#inf_custom_data" ).datepicker();
                        });
                        </script>
                        <br>
    <input type="submit" value="Agendar" style="margin-right: 40px;"><p><p>
</form>

<?php
        if(isset($_POST["data"])){
            require_once 'modelos/Pessoa.php';
            $pessoa = new Pessoa();
            $id = ($_SESSION["id"]);
            $nome = $_SESSION["usuario"];
            $pessoa->atividade = 'pilates';
            $pessoa->idaluno = $id;
            $pessoa->nome = $nome;
            $datamysql = $_POST['data']." ".$_POST['horario'];
            $pessoa->dataHora = $datamysql;
            
            if($pessoa->agendar()){
                echo '<script> alert("Agendado com sucesso");</script>';
            } else {
               echo '<script> alert("Erro ao cadastrar");</script>';
            }
        }
       ?>   