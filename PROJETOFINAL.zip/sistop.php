<div id="top">
    <header>
        <nav>
            <ul>
                <li>SISTEMA DE CADASTRO E CONTROLE</li>
                <li>Academia daFence</li>
                <li><a href='logoff.php'>Sair</a></li>
            </ul>
        </nav>
    </header>
</div>

