<div id="bottom">
    <footer>
        <nav>
            <ul>
                <li class="col">
                    <h4> DaFence</h4>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                </li>
                <li class="col">
                    <h4> DaFence</h4>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                </li>
                <li class="col">
                    <h4> DaFence</h4>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                </li>
                <li class="col">
                    <h4> DaFence</h4>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                </li>
                <li class="col">
                    <h4> DaFence</h4>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                    <ul>
                        <a href="">DaFence</a>
                    </ul>
                </li>

            </ul>
        </nav>
        <div id="func">
            <a href="index.php?p=loginf&c=sist"><img src="imagens/ph-func.jpg"></a>
        </div>
    </footer>
</div>