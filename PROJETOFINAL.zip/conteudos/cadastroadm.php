<div class="sistema">
<form name="form" method="post" onSubmit="return validaForm(this)" >
         <a class="voltar" href="index.php?p=func&c=sist">Voltar</a><p><h1>  Cadastro Funcionarios </h1>
        <h2>(*)Dados Obrigatórios</h2>
        Nome<br> <input type="text" size="40" maxlenght="60" required name="nome" title="Nome obrigatório."><p>
        CPF <br><input type="text" maxlenght="16" name="cpf"><p>
        RG<br> <input type="text" maxlenght="25" name="rg"><p>
        Telefone<br> <input type="text" maxlenght="25" name="tel"><p>
        Data Nasc<br> 
        <select name="dia">
            <?php
            for ($x = 1; $x <= 31; $x++){
                echo "<option value= $x > $x</option>";
            }
                    ?>
        </select>
        <select name="mes">
            <?php
            for ($x = 1; $x <= 12; $x++){
                echo "<option value= $x > $x</option>";
            }
                    ?>
        </select>
        <select name="ano">
            <?php
            $ano = date(Y);
            for ($x= $ano; $x >= $ano-120; $x--){
                echo "<option value= $x > $x</option>";
            }
                    ?>
        </select><p>
        Sexo <br>
            <input type="radio" name="sexo" checked>
                Masculino
            <input type="radio" name="sexo">
                Feminino <br>
        Endereço<br> <input type="text" size="40" maxlenght="100" name="endereco"><p>
        Numero <br><input type="text" size="5" maxlenght="20" name="numero"><p>
        Complemento <br><input type="text" size="5" maxlenght="20" name="comp"><p>
        Bairro <br><input type="text" size="40" maxlenght="45" name="bairro"><p>
        Cidade <br><input type="text" size="40" maxlenght="45" name="cidade"><p>
        Estado <br><input type="text" size="2" maxlenght="2" name="estado"><p>
        Email <br><input type="email" size="30" maxlenght="50" name="email"><p>
        Senha <br><input type="password" size="30" maxlenght="50" name="senha"><p>
            
        
        <input type="submit" value="Cadastrar" style="margin-left: 280px;"><p><p>
    </form> 

<?php
        if(isset($_POST["nome"])){
            require_once 'modelos/Pessoa.php';
            $pessoa = new Pessoa();
            $pessoa->nome = trim($_POST['nome']);
            $pessoa->endereco = trim($_POST['endereco']);
            $pessoa->bairro = trim($_POST['bairro']);
            $pessoa->cidade = trim($_POST['cidade']);
            $pessoa->estado = trim($_POST['estado']);
            $pessoa->numero = trim($_POST['numero']);
            $pessoa->complemento = trim($_POST['comp']);
            $pessoa->cpf = trim($_POST['cpf']);
            $pessoa->rg = trim($_POST['rg']);
            $pessoa->tel = trim($_POST['tel']);
            $pessoa->sexo = trim($_POST['sexo']);
            $datamysql = $_POST['ano']."-".$_POST['mes']."-".$_POST['dia'];
            $pessoa->datanasc = $datamysql;
            $pessoa->email = trim($_POST['email']);
            //$cripto = crypt(($_POST['senha']), '$1$salt$');
            //$pessoa->senha = $cripto;
            $pessoa->senha =  trim($_POST['senha']);
            var_dump($pessoa);
            
            if($pessoa->cadastrof()){
                echo '<script> alert("Cadastrado com sucesso");</script>';
                //header("Location:/index.php?p=inicio");
            } else {
               echo '<script> alert("Erro ao cadastrar");</script>';
            }
            
        /*$this->nome = $nome;
        $this->cpf = $cpf;
        $this->rg = $rg;
        $this->sexo = $sexo;
        $this->telefone = $telefone;
        $this->dataNasc = $dataNasc;
        $this->endereco = $endereco;
        $this->numero = $numero;
        $this->numero = $bairro;
        $this->cidade = $cidade;
        $this->estado =  $estado;*/
  }
        ?>
</div>